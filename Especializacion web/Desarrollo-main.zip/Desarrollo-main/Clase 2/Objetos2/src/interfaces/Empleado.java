package interfaces;

public interface Empleado {
    //contrato
    // String getNombre();
    // double getSueldo();
    // void trabajar();
    public void calcularSueldo();
}
