-- Carga de registros a una tabla y su recuperación

-- Cree una tabla llamada "agenda". Debe tener los siguientes campos:

-- apellido text
-- nombre text
-- domicilio text
-- telefono integer

-- Ingrese los siguientes registros:

 insert into agenda (apellido, nombre, domicilio, telefono)
  values ('Moreno','Alberto','Colon 123',4234567);
 insert into agenda (apellido,nombre, domicilio, telefono)
  values ('Torres','Juan','Avellaneda 135',4458787);
-- Recuperar todos los registros de la tabla "agenda"

-- Eliminar la tabla "agenda"

-- Intentar eliminar la tabla "agenda" nuevamente.

