-- Lista de usuarios
 SELECT * FROM mysql.user;
 
 -- ver el usuario actual
SELECT USER();

-- Crear un nuevo usuario
CREATE USER IF NOT EXISTS 'pepe'@'localhost' IDENTIFIED BY '123';

-- Otorgar privilegios específicos
GRANT SELECT, INSERT, UPDATE, DELETE ON negocio.* TO 'pepe'@'localhost';

-- Elimino privilegios al nuevo usuario
REVOKE SELECT, INSERT, UPDATE, DELETE ON negocio.* FROM 'pepe'@'localhost';

-- Ver los privilegios concedidos
SHOW GRANTS FOR 'pepe'@'localhost';

-- Otorgar todos los privilegios (si es necesario)
GRANT ALL PRIVILEGES ON *.* TO 'pepe'@'localhost' WITH GRANT OPTION;

-- Ver privilegios actualizados
SHOW GRANTS FOR 'pepe'@'localhost';

-- IMPORTANTE: Revocar privilegios ANTES de eliminar usuario
-- Revocar todos los privilegios (sintaxis correcta)
REVOKE ALL PRIVILEGES, GRANT OPTION FROM 'pepe'@'localhost';

-- Verificar que se revocaron
SHOW GRANTS FOR 'pepe'@'localhost';

-- Ahora sí eliminar el usuario
DROP USER 'pepe'@'localhost';

-- Verificar que se eliminó
SELECT User, Host FROM mysql.user WHERE User = 'pepe';

-- permisos para que un usuario manipule 2 bases a la vez
GRANT SELECT, INSERT, UPDATE, DELETE ON baseDatos1.*, baseDatos2.* TO 'miUsuario'@'localhost';